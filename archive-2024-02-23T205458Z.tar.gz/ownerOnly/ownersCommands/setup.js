const { SlashCommandBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, EmbedBuilder, ActionRowBuilder } = require("discord.js");
const { Database } = require("st.db");
const setting = new Database("/database/settingsdata/setting");
const { owner } = require('../../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setup')
    .setDescription('تسطيب النظام')
    .addUserOption(option => option
      .setName('recipient')
      .setDescription('مستلم الأرباح')
      .setRequired(false))
    .addChannelOption(option => option
      .setName('transferroom')
      .setDescription('روم تحويل من أجل شراء الرصيد')
      .setRequired(false))
    .addChannelOption(option => option
      .setName('logroom')
      .setDescription('روم لوج شراء البوتات')
      .setRequired(false))
    .addChannelOption(option => option
      .setName('panelroom')
      .setDescription('روم بانل شراء الرصيد')
      .setRequired(false))
    .addChannelOption(option => option
      .setName('buybotroom')
      .setDescription('روم بانل شراء البوتات')
      .setRequired(false))
    .addChannelOption(option => option
      .setName('subscriberoom')
      .setDescription('روم بانل شراء اشتراك ميكر')
      .setRequired(false))
    .addRoleOption(option => option
      .setName('clientrole')
      .setDescription('رول العملاء')
      .setRequired(false))
    .addUserOption(option => option
      .setName('probot')
      .setDescription('البروبوت')
      .setRequired(false)),
  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    let recipient = interaction.options.getUser('recipient');
    let transferroom = interaction.options.getChannel('transferroom');
    let logroom = interaction.options.getChannel('logroom');
    let panelroom = interaction.options.getChannel('panelroom');
    let subscriberoom = interaction.options.getChannel('subscriberoom');
    let buybotroom = interaction.options.getChannel('buybotroom');
    let clientrole = interaction.options.getRole('clientrole');
    let probot = interaction.options.getUser('probot');

    if (interaction.user.id !== owner) {
      return interaction.editReply({ content: 'لا يمكنك استخدام هذا الأمر!' });
    }

    if (recipient) {
      await setting.set(`recipient_${interaction.guild.id}`, recipient.id);
    }
    if (transferroom) {
      await setting.set(`transfer_room_${interaction.guild.id}`, transferroom.id);
    }
    if (logroom) {
      await setting.set(`log_room_${interaction.guild.id}`, logroom.id);
    }
    if (clientrole) {
      await setting.set(`client_role_${interaction.guild.id}`, clientrole.id);
    }
    if (probot) {
      await setting.set(`probot_${interaction.guild.id}`, probot.id);
    }
    if (panelroom) {
      await setting.set(`panel_room_${interaction.guild.id}`, panelroom.id);
    }
    if (buybotroom) {
      await setting.set(`buy_bot_room${interaction.guild.id}`, buybotroom.id);
    }
    if (subscriberoom) {
      await setting.set(`subscribe_room_${interaction.guild.id}`, subscriberoom.id);
    }

    if (!recipient && !subscriberoom && !transferroom && !logroom && !clientrole && !probot && !panelroom && !buybotroom && !buyprojectsroom) {
      return interaction.editReply({ content: '**الرجاء تحديد إعداد واحد على الأقل**' });
    }

    return interaction.editReply({ content: '**تم تحديد الإعدادات بنجاح**' });
  },
};
