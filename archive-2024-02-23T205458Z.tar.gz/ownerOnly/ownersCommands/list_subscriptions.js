const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { Database } = require("st.db");
const { clientId, owner } = require('../../config.json');

const tierSubscriptions = {
    tier1: new Database("/database/makers/tier1/subscriptions"),
    tier2: new Database("/database/makers/tier2/subscriptions"),
    tier3: new Database("/database/makers/tier3/subscriptions"),
};

module.exports = {
    data: new SlashCommandBuilder()
        .setName('list-subscriptions')
        .setDescription('عرض قائمة الاشتراكات في السيرفر')
        .addStringOption(option => option
            .setName('type')
            .setDescription('نوع الاشتراك')
            .setRequired(true)
            .addChoices(
              { name: 'البرايم', value: 'tier1' },
              { name: 'البيريميم', value: 'tier2' }, 
              { name: 'التيتم', value: 'tier3' },
            )
        )
        .addStringOption(option => option
            .setName('serverid')
            .setDescription('ايدي السيرفر')
            .setRequired(true)
        ),
    async execute(interaction) {
        await interaction.deferReply({ ephemeral: false });

        const type = interaction.options.getString('type');
        const serverID = interaction.options.getString('serverid');

        const subscriptions = tierSubscriptions[type];

        if (!subscriptions) {
            return interaction.editReply({ content: '**نوع الاشتراك غير صحيح**' });
        }

        const serverSubscriptions = subscriptions.get(`${type}_subs`).filter(su => su.guildid === serverID);

        if (serverSubscriptions.length === 0) {
            return interaction.editReply({ content: '**لا توجد اشتراكات بهذا الايدي في هذا النوع**' });
        }

        const subscriptionList = serverSubscriptions.map(sub => `ID: ${sub.id} - صاحب الاشتراك: ${sub.username}`).join('\n');

        const embed = new EmbedBuilder()
            .setFooter({
                text: interaction.user.username,
                iconURL: interaction.user.displayAvatarURL({ dynamic: true }),
            })
            .setAuthor({
                name: interaction.guild.name,
                iconURL: interaction.guild.iconURL({ dynamic: true }),
            })
            .setTimestamp(Date.now())
            .setColor('#00FF00')
            .setTitle('**قائمة الاشتراكات في السيرفر**')
            .setDescription(`**قائمة الاشتراكات للسيرفر ذو الايدي: \`${serverID}\` والنوع: \`${type}\`**\n\n${subscriptionList}`);

        return interaction.editReply({ embeds: [embed] });
    }
};
