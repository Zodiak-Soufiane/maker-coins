const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField, ActionRowBuilder, ButtonBuilder, MessageComponentCollector, ButtonStyle, Embed } = require("discord.js");
const { Database } = require("st.db");
const db = new Database("/database/data");
const { clientId, owner } = require('../../config.json');
const setting = new Database("/database/settingsdata/setting");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('send-balance-panel')
        .setDescription(`ارسال بانل شراء الرصيد`),
    async execute(interaction) {
        await interaction.deferReply({ ephemeral: false });
        let price1 = await setting.get(`balance_price_${interaction.guild.id}`) ?? 5000;
        let recipient = await setting.get(`recipient_${interaction.guild.id}`);
        let transferroom = await setting.get(`transfer_room_${interaction.guild.id}`);
        let logroom = await setting.get(`log_room_${interaction.guild.id}`);
        let probot = await setting.get(`probot_${interaction.guild.id}`);
        let clientrole = await setting.get(`client_role_${interaction.guild.id}`);
        let panelroom = await setting.get(`panel_room_${interaction.guild.id}`);
        let buybotroom = await setting.get(`buy_bot_room${interaction.guild.id}`);

        if (!price1 || !recipient || !transferroom || !logroom || !probot || !clientrole || !buybotroom) return interaction.editReply({ content: `**لم يتم تحديد الاعدادات**` });

        let theroom = interaction.guild.channels.cache.find(ch => ch.id == panelroom);
        let image = 'https://media.discordapp.net/attachments/1184509947749351424/1186326913418018958/11.png?ex=6592d809&is=65806309&hm=0a204381efc0ee63763b96aaa38ead9440afb47a06b74e58726572e2f3c33cc0&=&format=webp&quality=lossless';
        let embed = new EmbedBuilder()
          .setTitle(`بانل شراء رصيد`)
          .setDescription(`يمكنك شراء رصيد عن طريق الضغط على الزر`)
          .setImage(image)
          .setTimestamp();

      const free = new ButtonBuilder()
      .setCustomId(`BuyBalanceButton`)
      .setLabel('شراء الرصيد')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('🪙');

        const row = new ActionRowBuilder()
            .addComponents(free);

        theroom.send({ embeds: [embed], components: [row] });

        if (interaction.user.id !== owner) {
            return interaction.editReply({ content: `لا يمكنك استخدام هذا الأمر!` });
        }

        return interaction.editReply({ content: `**تم إرسال الرسالة بنجاح**` });
    }
};
