const { SlashCommandBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, EmbedBuilder, ActionRowBuilder } = require("discord.js");
const { Database } = require("st.db");
const db = new Database("/database/data");
const { owner } = require('../../config.json');
const setting = new Database("/database/settingsdata/setting");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('send-bots-panel')
        .setDescription(`ارسال بانل شراء البوتات`),
    async execute(interaction) {
        await interaction.deferReply({ ephemeral: false });
        let price1 = await setting.get(`balance_price_${interaction.guild.id}`) ?? 5000;
        let recipient = await setting.get(`recipient_${interaction.guild.id}`);
        let transferroom = await setting.get(`transfer_room_${interaction.guild.id}`);
        let logroom = await setting.get(`log_room_${interaction.guild.id}`);
        let probot = await setting.get(`probot_${interaction.guild.id}`);
        let clientrole = await setting.get(`client_role_${interaction.guild.id}`);
        let panelroom = await setting.get(`panel_room_${interaction.guild.id}`);
        let buybotroom = await setting.get(`buy_bot_room${interaction.guild.id}`);
        if (!price1 || !recipient || !transferroom || !logroom || !probot || !clientrole || !buybotroom) return interaction.editReply({ content: `**لم يتم تحديد الاعدادات**` });
        let theroom = interaction.guild.channels.cache.find(ch => ch.id == buybotroom);
      let panelImageURL = 'https://media.discordapp.net/attachments/1184566165914259536/1186068201457598597/12.png?ex=6591e717&is=657f7217&hm=767c3319347dcfbdcafc2a3b3f6ee7d815370167cf0879cca21ad6b2f7f4e048&=&format=webp&quality=lossless';

      let embed = new EmbedBuilder()
      .setTitle(`بائل شراء البوتات`)
      .setDescription(`يمكنك شراء بوت جاهز الخاص بك الان من هنا`)
      .setImage(panelImageURL)
      .setTimestamp()
      const select = new StringSelectMenuBuilder()
      .setCustomId('select_bot')
      .setPlaceholder('قم بأختيار البوت من القائمة')
      .addOptions(
          new StringSelectMenuOptionBuilder()
              .setLabel('بـوت تـقـديـمـات')
              .setDescription('شراء بوت تقديمات')
              .setValue('BuyApply'),
              new StringSelectMenuOptionBuilder()
              .setLabel('بـوت خـط تـلـقائـي')
              .setDescription('شراء بوت خط تلقائي')
              .setValue('BuyAutoline'),
              new StringSelectMenuOptionBuilder()
              .setLabel('بـوت بـلاكلـيـسـت')
              .setDescription('شراء بوت بلاك ليست')
              .setValue('BuyBlacklist'),
              new StringSelectMenuOptionBuilder()
              .setLabel('بـوت بـرودكـاسـت بـانـل')
              .setDescription('شراء بوت برودكاست')
              .setValue('BuyBroadcast'),
          new StringSelectMenuOptionBuilder()
              .setLabel('بـوت بـرودكـاسـت')
              .setDescription('شراء بوت برودكاست عادي')
              .setValue('BuyNormalBroadcast'),
              new StringSelectMenuOptionBuilder()
              .setLabel('بـوت كـريـديت')
              .setDescription('شراء بوت كريدت وهمي')
              .setValue('BuyCredit'),
              new StringSelectMenuOptionBuilder()
              .setLabel('بـوت فيـدباك')
              .setDescription('شراء بوت اراء')
              .setValue('BuyFeedback'),
              new StringSelectMenuOptionBuilder()
              .setLabel('بـوت جـيـفاواي')
              .setDescription('شراء بوت جيف اواي')
              .setValue('BuyGiveaway'),
              new StringSelectMenuOptionBuilder()
              .setLabel('بـوت لـوج')
              .setDescription('شراء بوت لوج')
              .setValue('BuyLogs'),
              new StringSelectMenuOptionBuilder()
              .setLabel('بـوت نـاديـكـو')
              .setDescription('شراء بوت ناديكو')
              .setValue('BuyNadeko'),
              new StringSelectMenuOptionBuilder()
              .setLabel('بـوت بـروبـوت')
              .setDescription('شراء بوت  بروبوت بريميوم وهمي')
              .setValue('BuyProbot'),
              new StringSelectMenuOptionBuilder()
              .setLabel('بـوت حـمـايـه')
              .setDescription('شراء بوت حماية')
              .setValue('BuyProtect'),
              new StringSelectMenuOptionBuilder()
              .setLabel('بـوت كـشـف نـصـابـيـن')
              .setDescription('شراء بوت نصابين')
              .setValue('BuyScammers'),
              new StringSelectMenuOptionBuilder()
              .setLabel('بـوت اقـتـراحـات')
              .setDescription('شراء بوت اقتراحات')
              .setValue('BuySuggestions'),
              new StringSelectMenuOptionBuilder()
              .setLabel('بـوت سـسـتـم')
              .setDescription('شراء بوت سيستم')
              .setValue('BuySystem'),
              new StringSelectMenuOptionBuilder()
              .setLabel('بـوت ضـريـبـة')
              .setDescription('شراء بوت ضريبة')
              .setValue('BuyTax'),
              new StringSelectMenuOptionBuilder()
              .setLabel('بـوت تـكـت')
              .setDescription('شراء بوت تكت')
              .setValue('BuyTicket'),
              new StringSelectMenuOptionBuilder()
              .setLabel('اعـاده تـحـمـيـل الـمـنـيـو')
              .setDescription('عمل اعادة تعيين للاختيار')
              .setValue('Reset_Selected'),
      );
        const row = new ActionRowBuilder()
            .addComponents(select);
        theroom.send({ embeds: [embed], components: [row] });
        if (setting.has(`subscribe_room_${interaction.guild.id}`)) {
            let subscriberoo = setting.get(`subscribe_room_${interaction.guild.id}`);
            let subscriberoom = interaction.guild.channels.cache.find(ch => ch.id == subscriberoo);
           let embed2 = new EmbedBuilder()
.setTitle(`بانل اشتراك في بوت الميكر`)
.setDescription(`يمكنك الاشتراك في بوت الميكر عن طريق القائمة`)
.setImage('https://media.discordapp.net/attachments/1184566165914259536/1186068704509841498/13.png?ex=6591e78f&is=657f728f&hm=4dc00cf20251e470123e2caf0c71c45f32577ae2fd727c86b914ae08f8a7ef2c&=&format=webp&quality=lossless')  
.setTimestamp()
const select2 = new StringSelectMenuBuilder()
.setCustomId('select_bot')
.setPlaceholder('الاشتراك في بوت الميكر')
.addOptions(
new StringSelectMenuOptionBuilder()
.setLabel('البـــرايـــم')
.setDescription('الاشـــتـــراك فــــي بــــوت المــــيـــكــــر البـــرايـــم')
.setValue('Bot_Maker_Subscribe'),
new StringSelectMenuOptionBuilder()
.setLabel('البـــريـــمــيـــم')
.setDescription('الاشـــتـــراك فــــي بــــوت المــــيـــكــــر البـــريـــمــيـــم')
.setValue('Bot_Maker_Premium_Subscribe'),
  new StringSelectMenuOptionBuilder()
  .setLabel('الـــتــــيــــم')
  .setDescription('الاشـــتـــراك فــــي بــــوت المــــيـــكــــر الـــتــــيــــم')
  .setValue('Bot_Maker_Ultimate_Subscribe'),
new StringSelectMenuOptionBuilder()
.setLabel('اعـاده تـحـمـيـل الـمـنـيـو')
.setDescription('bot by 3ky and https://discord.gg/g-p')
.setValue('Reset_Selected'),
);
            const row2 = new ActionRowBuilder().addComponents(select2);
            subscriberoom.send({ embeds: [embed2], components: [row2] });
        }
        if (interaction.user.id !== owner) {
            return interaction.editReply({ content: `لا يمكنك استخدام هذا الامر !` });
        }
        return interaction.editReply({ content: `**تم ارسال الرسالة بنجاح**` });
    }
}
