const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require("discord.js");
const { Database } = require("st.db");
const db = new Database("/database/usersdata/codes");
const { owner } = require('../../config.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('delete-code')
        .setDescription('حذف كود خصم')
        .addStringOption(Option =>
            Option
                .setName('code')
                .setDescription('الكود')
                .setRequired(true)),
    async execute(interaction) {
        await interaction.deferReply({ ephemeral: false });
        const thecode = interaction.options.getString(`code`);
        let codes = db.get(`codes_${interaction.guild.id}`);
        if (!codes) {
            await db.set(`codes_${interaction.guild.id}`, []);
        }
        codes = await db.get(`codes_${interaction.guild.id}`);
        let ownerFind = codes.find(re => re.code == thecode);
        if (interaction.user.id !== owner) {
            return interaction.editReply({ content: `لا يمكنك استخدام هذا الامر !` });
        }
        if (!ownerFind) return interaction.editReply({ content: `**هذا الكود غير متوفر للازالة**` });
        const filtered = codes.filter(re => re.code != thecode);
        await db.set(`codes_${interaction.guild.id}`, filtered);
        return interaction.editReply({ content: `**تم حذف الكود بنجاح**` });

    }
}
